// main.js : votre code. Gardez cette ligne : « chart » est le cadre où dessiner, comme dans les cellules du TD.
const chart = document.querySelector("#chart");

// ↓ Collez ici le code d'une cellule du TD (à la place de la démo), enregistrez : le navigateur se recharge.

// Démo : si vous voyez la phrase dans le navigateur et « 639 restaurants chargés » dans la console (F12), tout marche.
const restos = await d3.csv("data/restaurants.csv", d3.autoType);
console.log(restos.length, "restaurants chargés");
console.log(restos[0]);

d3.select(chart).append("h1").text("Le kit fonctionne : " + restos.length + " restaurants.");
